<?php

namespace IKTO\PgI\Exception;

class MissingConverterException extends InvalidArgumentException
{
}
