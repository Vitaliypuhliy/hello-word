<?php

namespace IKTO\PgI\Exception;

class TransactionException extends \RuntimeException
{
}
