<?php

namespace IKTO\PgI\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}
