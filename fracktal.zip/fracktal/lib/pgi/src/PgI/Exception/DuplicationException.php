<?php

namespace IKTO\PgI\Exception;

class DuplicationException extends \InvalidArgumentException
{
}
