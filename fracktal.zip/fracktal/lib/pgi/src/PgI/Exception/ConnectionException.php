<?php

namespace IKTO\PgI\Exception;

class ConnectionException extends \RuntimeException
{
}
