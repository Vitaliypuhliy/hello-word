<?php

namespace IKTO\PgI\Exception;

class QueryException extends \RuntimeException
{
}
