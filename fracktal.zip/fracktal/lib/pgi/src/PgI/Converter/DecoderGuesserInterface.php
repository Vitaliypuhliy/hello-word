<?php

namespace IKTO\PgI\Converter;

interface DecoderGuesserInterface
{
}
