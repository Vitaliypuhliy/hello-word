<?php

namespace IKTO\PgiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IktoPgiBundle extends Bundle
{
}
