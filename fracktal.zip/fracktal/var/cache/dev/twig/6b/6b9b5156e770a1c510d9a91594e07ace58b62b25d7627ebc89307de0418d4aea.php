<?php

/* blank.html.twig */
class __TwigTemplate_337d02ab2d95c71010b674d25c86e6c65b24d562c8c048f279b6ebd3137a48f7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blank.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_26d9c4eba40b6837253a493663924cea9cf180c89fceb4eef65f5da81a9847a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26d9c4eba40b6837253a493663924cea9cf180c89fceb4eef65f5da81a9847a0->enter($__internal_26d9c4eba40b6837253a493663924cea9cf180c89fceb4eef65f5da81a9847a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blank.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_26d9c4eba40b6837253a493663924cea9cf180c89fceb4eef65f5da81a9847a0->leave($__internal_26d9c4eba40b6837253a493663924cea9cf180c89fceb4eef65f5da81a9847a0_prof);

    }

    public function getTemplateName()
    {
        return "blank.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
", "blank.html.twig", "/home/dima/fracktal/app/Resources/views/blank.html.twig");
    }
}
