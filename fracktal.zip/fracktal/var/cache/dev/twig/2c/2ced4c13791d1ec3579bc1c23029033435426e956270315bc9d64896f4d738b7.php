<?php

/* base.html.twig */
class __TwigTemplate_440647f8cbd8d065ff7243003cd766cc1801b3093593e7b3e4236b6012227a5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f65d6c3eed91dbd1737df3896163853b0f1aedf2f7556a54d37666926015aeee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f65d6c3eed91dbd1737df3896163853b0f1aedf2f7556a54d37666926015aeee->enter($__internal_f65d6c3eed91dbd1737df3896163853b0f1aedf2f7556a54d37666926015aeee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "    </head>
    <body>
        <div id=\"page\">
            <header id=\"header\">
                <span class=\"logo\">&nbsp;</span>
            </header>
            ";
        // line 16
        $this->displayBlock('body', $context, $blocks);
        // line 17
        echo "Степанюк Дмитро та Пухлій Віталій
        </div>
        <footer id=\"footer\">
            © Черкаський національний університет ім. Богдана Хмельницького
        </footer>
        ";
        // line 22
        $this->displayBlock('javascripts', $context, $blocks);
        // line 23
        echo "    </body>
</html>
";
        
        $__internal_f65d6c3eed91dbd1737df3896163853b0f1aedf2f7556a54d37666926015aeee->leave($__internal_f65d6c3eed91dbd1737df3896163853b0f1aedf2f7556a54d37666926015aeee_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_81809705e5f556e938ee6b2fa54c86767d95b9a8e533beefdaaba3d72295ae19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81809705e5f556e938ee6b2fa54c86767d95b9a8e533beefdaaba3d72295ae19->enter($__internal_81809705e5f556e938ee6b2fa54c86767d95b9a8e533beefdaaba3d72295ae19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_81809705e5f556e938ee6b2fa54c86767d95b9a8e533beefdaaba3d72295ae19->leave($__internal_81809705e5f556e938ee6b2fa54c86767d95b9a8e533beefdaaba3d72295ae19_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_adfeced8b9c7cc7fe35187855f70077b5711f12611f9773529894370c176e799 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_adfeced8b9c7cc7fe35187855f70077b5711f12611f9773529894370c176e799->enter($__internal_adfeced8b9c7cc7fe35187855f70077b5711f12611f9773529894370c176e799_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("static/css/base.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_adfeced8b9c7cc7fe35187855f70077b5711f12611f9773529894370c176e799->leave($__internal_adfeced8b9c7cc7fe35187855f70077b5711f12611f9773529894370c176e799_prof);

    }

    // line 16
    public function block_body($context, array $blocks = array())
    {
        $__internal_8ed6ae11883b08b76be0cd15c0a3e4086182bb67bf108e5c1bfaef32032c07ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ed6ae11883b08b76be0cd15c0a3e4086182bb67bf108e5c1bfaef32032c07ba->enter($__internal_8ed6ae11883b08b76be0cd15c0a3e4086182bb67bf108e5c1bfaef32032c07ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_8ed6ae11883b08b76be0cd15c0a3e4086182bb67bf108e5c1bfaef32032c07ba->leave($__internal_8ed6ae11883b08b76be0cd15c0a3e4086182bb67bf108e5c1bfaef32032c07ba_prof);

    }

    // line 22
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b06fca2675af3a2272740edddadef0a257d4b7831dfe05cf75d81780550b79b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b06fca2675af3a2272740edddadef0a257d4b7831dfe05cf75d81780550b79b0->enter($__internal_b06fca2675af3a2272740edddadef0a257d4b7831dfe05cf75d81780550b79b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_b06fca2675af3a2272740edddadef0a257d4b7831dfe05cf75d81780550b79b0->leave($__internal_b06fca2675af3a2272740edddadef0a257d4b7831dfe05cf75d81780550b79b0_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 22,  97 => 16,  87 => 8,  81 => 7,  70 => 5,  61 => 23,  59 => 22,  52 => 17,  50 => 16,  42 => 10,  40 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
        {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('static/css/base.css') }}\">
        {% endblock %}
    </head>
    <body>
        <div id=\"page\">
            <header id=\"header\">
                <span class=\"logo\">&nbsp;</span>
            </header>
            {% block body %}{% endblock %}
Степанюк Дмитро та Пухлій Віталій
        </div>
        <footer id=\"footer\">
            © Черкаський національний університет ім. Богдана Хмельницького
        </footer>
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/home/dima/fracktal/app/Resources/views/base.html.twig");
    }
}
