<?php

/* IktoFracktalClientBundle:Login:index.html.twig */
class __TwigTemplate_47e0c633c09e878749aefbc1c2b01ffc08c224a8b68168ad416accc9c0585c6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "IktoFracktalClientBundle:Login:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_792ac7f046bfd4d0be387964867325135a673b4e767dbe5cb511af35bac491c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_792ac7f046bfd4d0be387964867325135a673b4e767dbe5cb511af35bac491c4->enter($__internal_792ac7f046bfd4d0be387964867325135a673b4e767dbe5cb511af35bac491c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "IktoFracktalClientBundle:Login:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_792ac7f046bfd4d0be387964867325135a673b4e767dbe5cb511af35bac491c4->leave($__internal_792ac7f046bfd4d0be387964867325135a673b4e767dbe5cb511af35bac491c4_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a67b66361662220a9124e3aee8440d4a5b5a9313e294736d35a17e11464867d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a67b66361662220a9124e3aee8440d4a5b5a9313e294736d35a17e11464867d9->enter($__internal_a67b66361662220a9124e3aee8440d4a5b5a9313e294736d35a17e11464867d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 5
            echo "        <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
    ";
        }
        // line 7
        echo "
    <form action=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("client.login");
        echo "\" method=\"post\">
        <label for=\"username\">Username:</label>
        <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" />

        <label for=\"password\">Password:</label>
        <input type=\"password\" id=\"password\" name=\"_password\" />

        <input type=\"hidden\" name=\"_target_path\" value=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("client.tests");
        echo "\" />

        <button type=\"submit\">login</button>
    </form>
";
        
        $__internal_a67b66361662220a9124e3aee8440d4a5b5a9313e294736d35a17e11464867d9->leave($__internal_a67b66361662220a9124e3aee8440d4a5b5a9313e294736d35a17e11464867d9_prof);

    }

    public function getTemplateName()
    {
        return "IktoFracktalClientBundle:Login:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 15,  57 => 10,  52 => 8,  49 => 7,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    {% if error %}
        <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
    {% endif %}

    <form action=\"{{ path('client.login') }}\" method=\"post\">
        <label for=\"username\">Username:</label>
        <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" />

        <label for=\"password\">Password:</label>
        <input type=\"password\" id=\"password\" name=\"_password\" />

        <input type=\"hidden\" name=\"_target_path\" value=\"{{ path('client.tests') }}\" />

        <button type=\"submit\">login</button>
    </form>
{% endblock %}
", "IktoFracktalClientBundle:Login:index.html.twig", "/home/dima/fracktal/src/Fracktal/ClientBundle/Resources/views/Login/index.html.twig");
    }
}
