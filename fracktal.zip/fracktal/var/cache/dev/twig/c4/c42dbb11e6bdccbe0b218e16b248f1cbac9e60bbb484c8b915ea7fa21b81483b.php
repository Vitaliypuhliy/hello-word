<?php

/* IktoPgiBundle:Collector:pgi.html.twig */
class __TwigTemplate_3d1454667ad220e41f96279ab89d9bb43447d4ed184795b8c3dfa36849ee5e50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("WebProfilerBundle:Profiler:layout.html.twig", "IktoPgiBundle:Collector:pgi.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "WebProfilerBundle:Profiler:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19ec97dd8a1d10582fdfc954a5db60d39e9212ff6159a6d3649a065783c2c794 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19ec97dd8a1d10582fdfc954a5db60d39e9212ff6159a6d3649a065783c2c794->enter($__internal_19ec97dd8a1d10582fdfc954a5db60d39e9212ff6159a6d3649a065783c2c794_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "IktoPgiBundle:Collector:pgi.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_19ec97dd8a1d10582fdfc954a5db60d39e9212ff6159a6d3649a065783c2c794->leave($__internal_19ec97dd8a1d10582fdfc954a5db60d39e9212ff6159a6d3649a065783c2c794_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_25c49d743ef4f751b818f07cc879c5afeae7470742958e65ae90972ab53ed006 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25c49d743ef4f751b818f07cc879c5afeae7470742958e65ae90972ab53ed006->enter($__internal_25c49d743ef4f751b818f07cc879c5afeae7470742958e65ae90972ab53ed006_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "    <img width=\"28\" height=\"28\" alt=\"Database\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3gYCFBU3VY6iYwAAB7xJREFUSMelVm1oFNsZfs6Z2d2Z3dndTDafZrORGKMuJrGpYjSmiFxixSgmP1qlqPgB+Xf7t3+E2gullkKRQvEitIiKvYaL0Qj3+hFJ/KJWxZhgtbqK5st8bnazcWd35sw5/dMZEsVeaN8/M8w5532e877Pec4QLIrJyckyy7JK/X4/I4QIIYRFCHlXUFAgJiYm7PLycp5IJH5UWFjIbNu2KaXC6/XOa5qWHBkZCVNKW1Op1G8ZY+UFBQVfRyKRXwPIB4PBNADMzs6CCCEwNTVVZprmWs75sYmJiZ+Mj48jm82iqKhIFBUVvdZ1vTcQCHwPQMtkMl8NDg4un56ehqqqiMViZiwWG2SMFV+9erUqkUjA5/OhqKjIamxs9Kxdu7YnEokc9/v9jwGAjIyMhLxe77fPnz//4ubNm3j27Bk455AkCZxzKIqCTZs2YdeuXeN3794N9/X1BVKpFAgh4JwDAMrLy7FlyxbU1tbi0aNHuHHjBiil4Jxj9erV2LZt29TmzZt/qShKFxkZGVmbTqf/fvLkyUAmk4Hf7welFEIIAABjDO3t7Zibm8O1a9fg8Xjg9XohhADnHIQQCCGQzWZRVlaGw4cP4969e7h9+zY0TYNhGPD5fNi3bx9vamraQvP5/Fd37twJTE9PIxAILGEuhEBVVRWi0Sj6+vrg8/kgy7JLhhACQgg8Hg9CoRAmJydx6tQpbN++HbW1tUilUlBVFaZpoqenhyaTyS8pIWT30NAQwuGwC8I5hxACQgi0tLTg1atXyOVyoJSCUuoCOe8OwWAwiA8fPuDcuXPYv38/IpEIOOfw+XzIZrMwTbOcyrJMDcOA1+t1F0qSBCEEPB4PVq5ciYcPH8K2bczPzyOXy4EQ4pKzbXtJRSzLwpMnT/DgwQPs2bMHuVzOHff5fB558a4c5k65AoEAbNuGaZpoa2tDRUUFEokEHj169ElZOedgjKG1tRXr16+H3+9HOp2GoihgjKGkpARer/cyZYwhGAyCMeYmAQDbtuHxeFBaWorOzk54vV6MjY2hpaUFO3bswMLCAiRJgiRJAIBMJoOOjg6sWrUKb9++RVdXlztumiYqKyshy/K/KCHkO13XYds2KKUuoNOjmZkZHD9+HD09PSgtLcWtW7cQj8dh27ZLUAgBWZaxbt06XLp0CQsLCzAMA7ZtI5/PI5/PIx6PM0rpExoMBn8Vi8WQzWbxcViWBcMw3IRdXV24d+8eAEBVVVdclFIwxpDP58E5x+XLl1FaWopMJgPDMFBSUoLKysr+cDg8Q23bVuvr610QIYTbFyeZJEnu2XOEIcvyEvEAwJ07d9DS0gLGmFslIQSampqgKMrvJEkyqNfrfVlcXDwVjUZhWZabVAiBQCAAwzBgWRYAuOCEEDDGlghM0zTcv38f9fX14JxjdnYWiqJA0zRUVFTcr6ysHCSECCqEQD6fl9etW7ckiRACqqoinU67BBhjkGUZiqIgn8+7PSeEQJIkLCws4MWLF2hra8PU1BQYY4jH46iurv4GwCwA0EwmIyWTSSkWi7nldJ7ZbBa6rruJTdNEdXU1ZmdnYVmWO9cpaTAYxJUrV7B7924UFBQgGAwiHo8P1tTU3CSE2IwxUF3XUytWrPirZVkIhULC2aUkSZicnISiKNi4cSNyuRwYY9i5cydu3boFTdNc0TghyzKSySQGBgZw9OhRyLKMurq679+8eZNwxmkoFLJt276g6/poNBrlpmm6JpDL5dDd3Y2Ojg5RXV39vq6uLheLxfD+/Xv4fD5XVE5wzqFpGrq7u1FYWJgyTfNbwzCerlixwnTmUEKI8Pl8j+vr63/f3NxsFhYWLrGqSCRiVFRUHOvs7Dx85MiRl5xz7N271wVw5i1WcGVlJYaHh23DMJ6GQqFcf39/4+Dg4BdjY2Mx+vDhQ0QiEXtmZubKmjVrepcvX84ty0I6nRZbt27lhw4d2t7b2/uXVCq1hxBScfr0aczNzaG5uRmGYSzpI+ccuVwOW7duRV9fX+T8+fO/OXv27NczMzM3FUXZ7/F4bHnDhg0AgIGBgeG2trYv29raitLpdFMgECAdHR2dw8PDP43H4z8fHR2tvnDhAnn9+jUOHDiA/v5+V9GL7ZBSCl3X37W2tv6jubm5xe/3PwHQrarqd8XFxeNECIHBwUE0NDTgzJkzpL29vSyZTO61bful3+/vTaVSf5ZleXRycvIYpXQ0EomoyWQykkgkcP36dSiKAs65670fPnzAiRMnjFwu9+OampoEAAKAEUI4AMgOy6dPn6KhoUEcPHjwPYA/LiJ+eGhoaLvf7x+ilJaqqlo9Pz//WFXVmsUqJYTAsiz4fD4Eg0ETwCpCyPOP7VJ2XhoaGj7x0qmpKZSUlKCuru4agGvO9/7+/tF0Ol2zuIwOaDgcRjgc/lNBQUH36OgoiUajYnFOiv8SJSUlS86ZE+vXr7/q/CQ5onFUq+s6xsfHNwPAx2A/COiw/jj8fv/fVFVdcj1JkoT/mAfS6bT+uXw/CPgZEmOFhYWMMeZewI6hV1VVQdf1rsW3yP8FuMg3ZzRNw/z8PCzLwtzcHDRNw5o1a96XlZX94XPVIfgf4927d9/Mzc397OLFi+Cco6GhAY2Njf9ctmzZL4LB4IBhGFBV9ZN1/wbSCfj8psqJGQAAAABJRU5ErkJggg==\" />
    <span class=\"sf-toolbar-status";
        // line 6
        if ((50 < $this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "count", array()))) {
            echo " sf-toolbar-status-yellow";
        }
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "count", array()), "html", null, true);
        echo "</span>
    ";
        // line 7
        if (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "count", array()) > 0)) {
            // line 8
            echo "        <span class=\"sf-toolbar-info-piece-additional-detail\">in ";
            echo twig_escape_filter($this->env, sprintf("%0.2f", ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "time", array()) * 1000)), "html", null, true);
            echo " ms</span>
    ";
        }
        // line 10
        echo "    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 11
        echo "    ";
        ob_start();
        // line 12
        echo "    <div class=\"sf-toolbar-info-piece\">
        <b>DB Queries</b>
        <span>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "count", array()), "html", null, true);
        echo "</span>
    </div>
    <div class=\"sf-toolbar-info-piece\">
        <b>Query time</b>
        <span>";
        // line 18
        echo twig_escape_filter($this->env, sprintf("%0.2f", ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "time", array()) * 1000)), "html", null, true);
        echo " ms</span>
    </div>
    ";
        $context["text"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 21
        echo "    ";
        $this->loadTemplate("WebProfilerBundle:Profiler:toolbar_item.html.twig", "IktoPgiBundle:Collector:pgi.html.twig", 21)->display(array_merge($context, array("link" => (isset($context["profiler_url"]) ? $context["profiler_url"] : $this->getContext($context, "profiler_url")))));
        
        $__internal_25c49d743ef4f751b818f07cc879c5afeae7470742958e65ae90972ab53ed006->leave($__internal_25c49d743ef4f751b818f07cc879c5afeae7470742958e65ae90972ab53ed006_prof);

    }

    // line 24
    public function block_menu($context, array $blocks = array())
    {
        $__internal_fcfeb7302a56023257378b0924331d39f015b8ee2b99f28191efe7f115d1418a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fcfeb7302a56023257378b0924331d39f015b8ee2b99f28191efe7f115d1418a->enter($__internal_fcfeb7302a56023257378b0924331d39f015b8ee2b99f28191efe7f115d1418a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 25
        echo "<span class=\"label\">
    <span class=\"icon\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3gYBFQAc3fB47gAACRFJREFUWMOtVmtsU+cZfr5zP77XSZzFNqRxGjXEkskMpaIXVKQQClRobQCp6jSkUVVqp46faCsCiU4aWn8M9Uerqi1orENdqkZR1TASVYo0sqVQBVC4JCWFktrBF+yovsTH5/rtRzmnNl2rqd0rHdk+fr/vfd73eW/APbK4uNh9+/btHkppF6W0q16vr8J/kbm5uaRpmt22HqW0nVIqA0Aul+taXl7+zfz8fO7y5cs0lUqNUko7crlcy733kFpNgcslAwCKxeLzgiAcvnXrVmuhUNAVRUEoFDJCodDtSCTy9+XlZb2tre2ooij7VVX97YULF36Wz+dNQRAQiURqsVhsxe/3n5mZmdkzMjLSalkWJElCIBCorFmzhmzatCnl9Xp/TwgZrSoKPLIMAgCFQuEPpVLpd4uLi8zIyAgymQwopWAYBpRSuFwuRKNRDA0NaQ8++ODwmTNnfjk+Po5SqQQAoJQCAHw+HzZs2IAnn3wShUIBJ06cwNdffw3TNGEYBoLBIHbv3o0NGzac8Pl8zxNCLDI/Px/t6Og4OTY2tnl0dBQul8sxTAgBABiGAa/Xi8OHD+P48eOYnZ0Fx3HgOA6UUliW5YTU/r5jxw488sgjeOWVV0AphSiKoJRCURQ8+uijeOGFF85Wq9Xt7IEDB9beuXPnyBtvvAG32w2WZQHA+SSEoFqtYt++fbhy5QrGxsbg9XpBCHEeW0+SJBBCwDAMZmZm4PP58Mwzz2B6etoBJggC5ubmUK1WO5PJ5AJjGMbfxsfHLZ7nncOEEJim6XjU3d2NeDyO06dPIxgMgmVZxzAAMAwDhmFgGIYDyuv14sMPP4Sqqti2bRtWVlYcWgOBAC5evIhisfgrhmXZValUipFlGRzHwbIsWJYFSikopTAMA4ODg7h06RJ0XXcosYE2PvYZhmHA8zw8Hg/efvttbN68GYlEAizLNulYlmUyPM+jXq9DEATHa0KIo8yyLOLxOD799FMAgKIoqNVq0HXdiQKlFKZpOsDtyNXrdWSzWZw6dQrPPfdck2OEEIiiyHONydPIqQ1ElmUQQpBOpxGPxxGPx8HzPGZnZzE3N9eUK7aYpgnTNLFlyxb09/dDFEW0t7cjEAg4lRMIBCDL8seMruvweDzOoUaxLAs8z4PjOBw6dAgDAwMoFovIZDIYGhrCY489BkVRwDBMU14oioJdu3ahv78fqVQKw8PD0HUdDMOA4zjouo5oNAqe528wAO54PB4n3I2e2NXAsizefPNNvPrqq8hms9i5cyfOnTuHdevWOXnRmAculwsPPfQQPvroI3R0dCCTyYBlWaiqCtM0oWka4vH4CiHkIuP3+3dHIhEoitLEoX2pZVmo1Wr44osv4PP5sLCwgNdeew2Tk5NwuVyQJMlJXFufYRgIgoClpSUcO3YMwWAQlUrFsSFJEvr6+q7V6/UcI8tyKhaLVe0QNQqlFJqmOblgN558Pu9QJgiCo0sphSAIKJfLyOfzCIfD4DgOHo8HlmXBMAzouo5kMolgMHjqvvvuU5hcLudPJBIen8/nXGJ7Y3NmA+E4Dna/sAHYenfLCoZhgGVZjI+PY2BgAJVKBbVaDQzDQBRFiKKIwcHB64SQYwDArFq16qIgCBd6e3ubKLCBeDwe1Ot1aJoGy7JgmqYDjGEYJwfs2mZZFpIk4cqVK4hEInC73cjn85AkCZRShMNhhMPhD5wmRimVs9msd+PGjc4ljYkoiiIqlYpj2PZSEASIoghN05qos8/WajVcu3YNO3bsQLlcdpra9u3bV7xe7wkHAAA2lUoJsVisqa/bzUJRFAQCAXAc54RX0zR0dXVheXm5KQKNXU6SJExMTGDLli1oaflmDVizZg0efvjh9ziOu+EAIIRU4/H4X0ulEkKhkEODHYl8Pg+e57Fx40bouu78t3XrVkxNTTlTrrF67PLN5/O4fv06XnzxReTzeTz99NNfZTKZk416DAC0t7cPl0qlYk9PT6VarTZxrWkahoeH8eyzzyIcDkNVVYRCIUSjUVy6dAl28t5L3d1Wi9HRUcRiMaysrNzRdb0jGo3++6vUkqPH3VW+nMlk/tTV1XXw3LlzThVQSsFxHKanp+lTTz1FXn755eFUKsW2trYOWZaFZDKJ8+fPw+12N5UuIcTpfLlcDjdv3sT69esHFhcXWwFg9arIt0AbNho2nU6Pfv7554MnT54U7NmtaRr2799fSiaTOwkh/zx//vz2zs7OsXQ6jVAohLfeegupVAo8z3+Hvmq1ij179mD16tV0YWGBxOPxs5VK5Uy9XmcikYjs9/tHuIako5qmvdvX1xdua2tLZrNZVCoVunfv3tratWsT09PTS5OTk/9oa2t74ubNmzh69Ch27dqF9evX49atW+B5vqmEDcMAANx///2Ympoi09PTOHv27OOxWOzxRCKBYDB4wO/3zzqkKXUVsiSiXC73Z7PZyXfeeSfQ2dmJl156afuNGze2iqI4VCwWo/ZWFAqFcOjQIYyNjeGTTz6BIAhOS2YYBqZpQtd1HDx48Kvu7u7hUqk04Ha7Cy6XawzAGCFkoV7X0TR5isUi0uk0H4vForVa7RcAPmtvb5+6evXqX1paWt7LZDITxWIR4XB4XpKklqWlpbZ0Oo2JiQlnkBmGAUopeJ6Hqqo4cuQI6vX6pt7e3rONtlRVgygK4Bpf3q1XXVGNL9u93j8DwLWr8+iL9+7N5/NBSum/gsFgRNM0d19fX2h8fDwrSVJ7Y+htSnVdhyiKcLvdBsdxPwfQBEAUhW+r4F6RxW9f98V7AQChUGiZUvoEABchpHzXUI5S2m4btAeTvSe63W4EAoHXOZ5/vXHL/k4f+F+FEGLYxgEgkUjM2IPJLtvGSAQCARQKhX5yz8b0owHcK8Fg8DjP847HjdPRNE14vV6Uy+U2Sin5vjt+EgCe5+ftWW8vI3YbNgwDfr8fqqoahBD6fweg6BYIIYVgMFi0S89uQPbv7u5u9PT0/PGH7vnRAGT+m6OyLBcikQjK5TIMw4CqqqjVaujo6MADDzzwmSzLH6iq9v15hZ8oi4uL7xJCfv3+++8jl8shFAph3bp1iMfjk62trft4nv/yh87/B4P9wzZb2pGKAAAAAElFTkSuQmCC\" alt=\"\" /></span>
    <strong>PostgreSQL</strong>
    <span class=\"count\">
        <span>";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "count", array()), "html", null, true);
        echo "</span>
        <span>";
        // line 30
        echo twig_escape_filter($this->env, sprintf("%0.0f", ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "time", array()) * 1000)), "html", null, true);
        echo " ms</span>
    </span>
</span>
";
        
        $__internal_fcfeb7302a56023257378b0924331d39f015b8ee2b99f28191efe7f115d1418a->leave($__internal_fcfeb7302a56023257378b0924331d39f015b8ee2b99f28191efe7f115d1418a_prof);

    }

    // line 35
    public function block_panel($context, array $blocks = array())
    {
        $__internal_fa47e21035724f1ed728757d68903edf768ba465cbe324aaf7e90bfd26125255 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa47e21035724f1ed728757d68903edf768ba465cbe324aaf7e90bfd26125255->enter($__internal_fa47e21035724f1ed728757d68903edf768ba465cbe324aaf7e90bfd26125255_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 36
        echo "    <h2>Queries</h2>
    ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "queries", array()));
        foreach ($context['_seq'] as $context["connection"] => $context["queries"]) {
            // line 38
            echo "        <h3>Connection <em>";
            echo twig_escape_filter($this->env, $context["connection"], "html", null, true);
            echo "</em></h3>
        ";
            // line 39
            if (twig_test_empty($context["queries"])) {
                // line 40
                echo "        <p>
            <em>No queries.</em>
        </p>
        ";
            } else {
                // line 44
                echo "            <table>
                <tr>
                    <th>Operation</th>
                    <th>Query</th>
                    <th>Time (ms)</th>
                </tr>
                ";
                // line 50
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["queries"]);
                foreach ($context['_seq'] as $context["i"] => $context["query"]) {
                    // line 51
                    echo "                <tr>
                    <td>
                        ";
                    // line 53
                    if ($this->getAttribute($context["query"], "type_query", array(), "any", true, true)) {
                        // line 54
                        echo "                        QUERY
                        ";
                    } elseif ($this->getAttribute(                    // line 55
$context["query"], "type_prepare", array(), "any", true, true)) {
                        // line 56
                        echo "                        PREPARE
                        ";
                    } elseif ($this->getAttribute(                    // line 57
$context["query"], "type_execute", array(), "any", true, true)) {
                        // line 58
                        echo "                        EXECUTE
                        ";
                    }
                    // line 60
                    echo "                    </td>
                    <td>
                        ";
                    // line 62
                    echo twig_escape_filter($this->env, $this->getAttribute($context["query"], "sql", array()), "html", null, true);
                    echo " <br>
                        <small>
                            <strong>Parameters:</strong> ";
                    // line 64
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\YamlExtension')->encode($this->getAttribute($context["query"], "params", array())), "html", null, true);
                    echo "
                        </small>
                    </td>
                    <td>
                        ";
                    // line 68
                    if ($this->getAttribute($context["query"], "duration", array(), "any", true, true)) {
                        // line 69
                        echo "                        ";
                        echo twig_escape_filter($this->env, sprintf("%0.2f", ($this->getAttribute($context["query"], "duration", array()) * 1000)), "html", null, true);
                        echo "
                        ";
                    } else {
                        // line 71
                        echo "                        &mdash;
                        ";
                    }
                    // line 73
                    echo "                    </td>
                </tr>
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['i'], $context['query'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 76
                echo "            </table>
        ";
            }
            // line 78
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['connection'], $context['queries'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "    <style>
        h3 { margin-bottom: 0; }
    </style>
";
        
        $__internal_fa47e21035724f1ed728757d68903edf768ba465cbe324aaf7e90bfd26125255->leave($__internal_fa47e21035724f1ed728757d68903edf768ba465cbe324aaf7e90bfd26125255_prof);

    }

    public function getTemplateName()
    {
        return "IktoPgiBundle:Collector:pgi.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 79,  220 => 78,  216 => 76,  208 => 73,  204 => 71,  198 => 69,  196 => 68,  189 => 64,  184 => 62,  180 => 60,  176 => 58,  174 => 57,  171 => 56,  169 => 55,  166 => 54,  164 => 53,  160 => 51,  156 => 50,  148 => 44,  142 => 40,  140 => 39,  135 => 38,  131 => 37,  128 => 36,  122 => 35,  111 => 30,  107 => 29,  101 => 25,  95 => 24,  87 => 21,  81 => 18,  74 => 14,  70 => 12,  67 => 11,  64 => 10,  58 => 8,  56 => 7,  48 => 6,  45 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'WebProfilerBundle:Profiler:layout.html.twig' %}

{% block toolbar %}
    {% set icon %}
    <img width=\"28\" height=\"28\" alt=\"Database\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3gYCFBU3VY6iYwAAB7xJREFUSMelVm1oFNsZfs6Z2d2Z3dndTDafZrORGKMuJrGpYjSmiFxixSgmP1qlqPgB+Xf7t3+E2gullkKRQvEitIiKvYaL0Qj3+hFJ/KJWxZhgtbqK5st8bnazcWd35sw5/dMZEsVeaN8/M8w5532e877Pec4QLIrJyckyy7JK/X4/I4QIIYRFCHlXUFAgJiYm7PLycp5IJH5UWFjIbNu2KaXC6/XOa5qWHBkZCVNKW1Op1G8ZY+UFBQVfRyKRXwPIB4PBNADMzs6CCCEwNTVVZprmWs75sYmJiZ+Mj48jm82iqKhIFBUVvdZ1vTcQCHwPQMtkMl8NDg4un56ehqqqiMViZiwWG2SMFV+9erUqkUjA5/OhqKjIamxs9Kxdu7YnEokc9/v9jwGAjIyMhLxe77fPnz//4ubNm3j27Bk455AkCZxzKIqCTZs2YdeuXeN3794N9/X1BVKpFAgh4JwDAMrLy7FlyxbU1tbi0aNHuHHjBiil4Jxj9erV2LZt29TmzZt/qShKFxkZGVmbTqf/fvLkyUAmk4Hf7welFEIIAABjDO3t7Zibm8O1a9fg8Xjg9XohhADnHIQQCCGQzWZRVlaGw4cP4969e7h9+zY0TYNhGPD5fNi3bx9vamraQvP5/Fd37twJTE9PIxAILGEuhEBVVRWi0Sj6+vrg8/kgy7JLhhACQgg8Hg9CoRAmJydx6tQpbN++HbW1tUilUlBVFaZpoqenhyaTyS8pIWT30NAQwuGwC8I5hxACQgi0tLTg1atXyOVyoJSCUuoCOe8OwWAwiA8fPuDcuXPYv38/IpEIOOfw+XzIZrMwTbOcyrJMDcOA1+t1F0qSBCEEPB4PVq5ciYcPH8K2bczPzyOXy4EQ4pKzbXtJRSzLwpMnT/DgwQPs2bMHuVzOHff5fB558a4c5k65AoEAbNuGaZpoa2tDRUUFEokEHj169ElZOedgjKG1tRXr16+H3+9HOp2GoihgjKGkpARer/cyZYwhGAyCMeYmAQDbtuHxeFBaWorOzk54vV6MjY2hpaUFO3bswMLCAiRJgiRJAIBMJoOOjg6sWrUKb9++RVdXlztumiYqKyshy/K/KCHkO13XYds2KKUuoNOjmZkZHD9+HD09PSgtLcWtW7cQj8dh27ZLUAgBWZaxbt06XLp0CQsLCzAMA7ZtI5/PI5/PIx6PM0rpExoMBn8Vi8WQzWbxcViWBcMw3IRdXV24d+8eAEBVVVdclFIwxpDP58E5x+XLl1FaWopMJgPDMFBSUoLKysr+cDg8Q23bVuvr610QIYTbFyeZJEnu2XOEIcvyEvEAwJ07d9DS0gLGmFslIQSampqgKMrvJEkyqNfrfVlcXDwVjUZhWZabVAiBQCAAwzBgWRYAuOCEEDDGlghM0zTcv38f9fX14JxjdnYWiqJA0zRUVFTcr6ysHCSECCqEQD6fl9etW7ckiRACqqoinU67BBhjkGUZiqIgn8+7PSeEQJIkLCws4MWLF2hra8PU1BQYY4jH46iurv4GwCwA0EwmIyWTSSkWi7nldJ7ZbBa6rruJTdNEdXU1ZmdnYVmWO9cpaTAYxJUrV7B7924UFBQgGAwiHo8P1tTU3CSE2IwxUF3XUytWrPirZVkIhULC2aUkSZicnISiKNi4cSNyuRwYY9i5cydu3boFTdNc0TghyzKSySQGBgZw9OhRyLKMurq679+8eZNwxmkoFLJt276g6/poNBrlpmm6JpDL5dDd3Y2Ojg5RXV39vq6uLheLxfD+/Xv4fD5XVE5wzqFpGrq7u1FYWJgyTfNbwzCerlixwnTmUEKI8Pl8j+vr63/f3NxsFhYWLrGqSCRiVFRUHOvs7Dx85MiRl5xz7N271wVw5i1WcGVlJYaHh23DMJ6GQqFcf39/4+Dg4BdjY2Mx+vDhQ0QiEXtmZubKmjVrepcvX84ty0I6nRZbt27lhw4d2t7b2/uXVCq1hxBScfr0aczNzaG5uRmGYSzpI+ccuVwOW7duRV9fX+T8+fO/OXv27NczMzM3FUXZ7/F4bHnDhg0AgIGBgeG2trYv29raitLpdFMgECAdHR2dw8PDP43H4z8fHR2tvnDhAnn9+jUOHDiA/v5+V9GL7ZBSCl3X37W2tv6jubm5xe/3PwHQrarqd8XFxeNECIHBwUE0NDTgzJkzpL29vSyZTO61bful3+/vTaVSf5ZleXRycvIYpXQ0EomoyWQykkgkcP36dSiKAs65670fPnzAiRMnjFwu9+OampoEAAKAEUI4AMgOy6dPn6KhoUEcPHjwPYA/LiJ+eGhoaLvf7x+ilJaqqlo9Pz//WFXVmsUqJYTAsiz4fD4Eg0ETwCpCyPOP7VJ2XhoaGj7x0qmpKZSUlKCuru4agGvO9/7+/tF0Ol2zuIwOaDgcRjgc/lNBQUH36OgoiUajYnFOiv8SJSUlS86ZE+vXr7/q/CQ5onFUq+s6xsfHNwPAx2A/COiw/jj8fv/fVFVdcj1JkoT/mAfS6bT+uXw/CPgZEmOFhYWMMeZewI6hV1VVQdf1rsW3yP8FuMg3ZzRNw/z8PCzLwtzcHDRNw5o1a96XlZX94XPVIfgf4927d9/Mzc397OLFi+Cco6GhAY2Njf9ctmzZL4LB4IBhGFBV9ZN1/wbSCfj8psqJGQAAAABJRU5ErkJggg==\" />
    <span class=\"sf-toolbar-status{% if 50 < collector.count %} sf-toolbar-status-yellow{% endif %}\">{{ collector.count }}</span>
    {% if collector.count > 0 %}
        <span class=\"sf-toolbar-info-piece-additional-detail\">in {{ '%0.2f'|format(collector.time * 1000) }} ms</span>
    {% endif %}
    {% endset %}
    {% set text %}
    <div class=\"sf-toolbar-info-piece\">
        <b>DB Queries</b>
        <span>{{ collector.count }}</span>
    </div>
    <div class=\"sf-toolbar-info-piece\">
        <b>Query time</b>
        <span>{{ '%0.2f'|format(collector.time * 1000) }} ms</span>
    </div>
    {% endset %}
    {% include 'WebProfilerBundle:Profiler:toolbar_item.html.twig' with { 'link': profiler_url } %}
{% endblock toolbar %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\"><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3gYBFQAc3fB47gAACRFJREFUWMOtVmtsU+cZfr5zP77XSZzFNqRxGjXEkskMpaIXVKQQClRobQCp6jSkUVVqp46faCsCiU4aWn8M9Uerqi1orENdqkZR1TASVYo0sqVQBVC4JCWFktrBF+yovsTH5/rtRzmnNl2rqd0rHdk+fr/vfd73eW/APbK4uNh9+/btHkppF6W0q16vr8J/kbm5uaRpmt22HqW0nVIqA0Aul+taXl7+zfz8fO7y5cs0lUqNUko7crlcy733kFpNgcslAwCKxeLzgiAcvnXrVmuhUNAVRUEoFDJCodDtSCTy9+XlZb2tre2ooij7VVX97YULF36Wz+dNQRAQiURqsVhsxe/3n5mZmdkzMjLSalkWJElCIBCorFmzhmzatCnl9Xp/TwgZrSoKPLIMAgCFQuEPpVLpd4uLi8zIyAgymQwopWAYBpRSuFwuRKNRDA0NaQ8++ODwmTNnfjk+Po5SqQQAoJQCAHw+HzZs2IAnn3wShUIBJ06cwNdffw3TNGEYBoLBIHbv3o0NGzac8Pl8zxNCLDI/Px/t6Og4OTY2tnl0dBQul8sxTAgBABiGAa/Xi8OHD+P48eOYnZ0Fx3HgOA6UUliW5YTU/r5jxw488sgjeOWVV0AphSiKoJRCURQ8+uijeOGFF85Wq9Xt7IEDB9beuXPnyBtvvAG32w2WZQHA+SSEoFqtYt++fbhy5QrGxsbg9XpBCHEeW0+SJBBCwDAMZmZm4PP58Mwzz2B6etoBJggC5ubmUK1WO5PJ5AJjGMbfxsfHLZ7nncOEEJim6XjU3d2NeDyO06dPIxgMgmVZxzAAMAwDhmFgGIYDyuv14sMPP4Sqqti2bRtWVlYcWgOBAC5evIhisfgrhmXZValUipFlGRzHwbIsWJYFSikopTAMA4ODg7h06RJ0XXcosYE2PvYZhmHA8zw8Hg/efvttbN68GYlEAizLNulYlmUyPM+jXq9DEATHa0KIo8yyLOLxOD799FMAgKIoqNVq0HXdiQKlFKZpOsDtyNXrdWSzWZw6dQrPPfdck2OEEIiiyHONydPIqQ1ElmUQQpBOpxGPxxGPx8HzPGZnZzE3N9eUK7aYpgnTNLFlyxb09/dDFEW0t7cjEAg4lRMIBCDL8seMruvweDzOoUaxLAs8z4PjOBw6dAgDAwMoFovIZDIYGhrCY489BkVRwDBMU14oioJdu3ahv78fqVQKw8PD0HUdDMOA4zjouo5oNAqe528wAO54PB4n3I2e2NXAsizefPNNvPrqq8hms9i5cyfOnTuHdevWOXnRmAculwsPPfQQPvroI3R0dCCTyYBlWaiqCtM0oWka4vH4CiHkIuP3+3dHIhEoitLEoX2pZVmo1Wr44osv4PP5sLCwgNdeew2Tk5NwuVyQJMlJXFufYRgIgoClpSUcO3YMwWAQlUrFsSFJEvr6+q7V6/UcI8tyKhaLVe0QNQqlFJqmOblgN558Pu9QJgiCo0sphSAIKJfLyOfzCIfD4DgOHo8HlmXBMAzouo5kMolgMHjqvvvuU5hcLudPJBIen8/nXGJ7Y3NmA+E4Dna/sAHYenfLCoZhgGVZjI+PY2BgAJVKBbVaDQzDQBRFiKKIwcHB64SQYwDArFq16qIgCBd6e3ubKLCBeDwe1Ot1aJoGy7JgmqYDjGEYJwfs2mZZFpIk4cqVK4hEInC73cjn85AkCZRShMNhhMPhD5wmRimVs9msd+PGjc4ljYkoiiIqlYpj2PZSEASIoghN05qos8/WajVcu3YNO3bsQLlcdpra9u3bV7xe7wkHAAA2lUoJsVisqa/bzUJRFAQCAXAc54RX0zR0dXVheXm5KQKNXU6SJExMTGDLli1oaflmDVizZg0efvjh9ziOu+EAIIRU4/H4X0ulEkKhkEODHYl8Pg+e57Fx40bouu78t3XrVkxNTTlTrrF67PLN5/O4fv06XnzxReTzeTz99NNfZTKZk416DAC0t7cPl0qlYk9PT6VarTZxrWkahoeH8eyzzyIcDkNVVYRCIUSjUVy6dAl28t5L3d1Wi9HRUcRiMaysrNzRdb0jGo3++6vUkqPH3VW+nMlk/tTV1XXw3LlzThVQSsFxHKanp+lTTz1FXn755eFUKsW2trYOWZaFZDKJ8+fPw+12N5UuIcTpfLlcDjdv3sT69esHFhcXWwFg9arIt0AbNho2nU6Pfv7554MnT54U7NmtaRr2799fSiaTOwkh/zx//vz2zs7OsXQ6jVAohLfeegupVAo8z3+Hvmq1ij179mD16tV0YWGBxOPxs5VK5Uy9XmcikYjs9/tHuIako5qmvdvX1xdua2tLZrNZVCoVunfv3tratWsT09PTS5OTk/9oa2t74ubNmzh69Ch27dqF9evX49atW+B5vqmEDcMAANx///2Ympoi09PTOHv27OOxWOzxRCKBYDB4wO/3zzqkKXUVsiSiXC73Z7PZyXfeeSfQ2dmJl156afuNGze2iqI4VCwWo/ZWFAqFcOjQIYyNjeGTTz6BIAhOS2YYBqZpQtd1HDx48Kvu7u7hUqk04Ha7Cy6XawzAGCFkoV7X0TR5isUi0uk0H4vForVa7RcAPmtvb5+6evXqX1paWt7LZDITxWIR4XB4XpKklqWlpbZ0Oo2JiQlnkBmGAUopeJ6Hqqo4cuQI6vX6pt7e3rONtlRVgygK4Bpf3q1XXVGNL9u93j8DwLWr8+iL9+7N5/NBSum/gsFgRNM0d19fX2h8fDwrSVJ7Y+htSnVdhyiKcLvdBsdxPwfQBEAUhW+r4F6RxW9f98V7AQChUGiZUvoEABchpHzXUI5S2m4btAeTvSe63W4EAoHXOZ5/vXHL/k4f+F+FEGLYxgEgkUjM2IPJLtvGSAQCARQKhX5yz8b0owHcK8Fg8DjP847HjdPRNE14vV6Uy+U2Sin5vjt+EgCe5+ftWW8vI3YbNgwDfr8fqqoahBD6fweg6BYIIYVgMFi0S89uQPbv7u5u9PT0/PGH7vnRAGT+m6OyLBcikQjK5TIMw4CqqqjVaujo6MADDzzwmSzLH6iq9v15hZ8oi4uL7xJCfv3+++8jl8shFAph3bp1iMfjk62trft4nv/yh87/B4P9wzZb2pGKAAAAAElFTkSuQmCC\" alt=\"\" /></span>
    <strong>PostgreSQL</strong>
    <span class=\"count\">
        <span>{{ collector.count }}</span>
        <span>{{ '%0.0f'|format(collector.time * 1000) }} ms</span>
    </span>
</span>
{% endblock menu %}

{% block panel %}
    <h2>Queries</h2>
    {% for connection, queries in collector.queries %}
        <h3>Connection <em>{{ connection }}</em></h3>
        {% if queries is empty %}
        <p>
            <em>No queries.</em>
        </p>
        {% else %}
            <table>
                <tr>
                    <th>Operation</th>
                    <th>Query</th>
                    <th>Time (ms)</th>
                </tr>
                {% for i, query in queries %}
                <tr>
                    <td>
                        {% if query.type_query is defined %}
                        QUERY
                        {% elseif query.type_prepare is defined %}
                        PREPARE
                        {% elseif query.type_execute is defined %}
                        EXECUTE
                        {% endif %}
                    </td>
                    <td>
                        {{ query.sql }} <br>
                        <small>
                            <strong>Parameters:</strong> {{ query.params|yaml_encode }}
                        </small>
                    </td>
                    <td>
                        {% if query.duration is defined %}
                        {{ '%0.2f'|format(query.duration * 1000) }}
                        {% else %}
                        &mdash;
                        {% endif %}
                    </td>
                </tr>
                {% endfor %}
            </table>
        {% endif %}
    {% endfor %}
    <style>
        h3 { margin-bottom: 0; }
    </style>
{% endblock panel %}
", "IktoPgiBundle:Collector:pgi.html.twig", "/home/dima/fracktal/lib/pgi-bundle/src/Resources/views/Collector/pgi.html.twig");
    }
}
