<?php

namespace IKTO\Fracktal\ManagerBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class TestsController extends Controller
{

    public function indexAction()
    {
        // @TODO Implement actual controller
        return $this->render('blank.html.twig');
    }
}
