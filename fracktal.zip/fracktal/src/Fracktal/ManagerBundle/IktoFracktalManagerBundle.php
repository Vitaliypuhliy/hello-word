<?php

namespace IKTO\Fracktal\ManagerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IktoFracktalManagerBundle extends Bundle
{
}
