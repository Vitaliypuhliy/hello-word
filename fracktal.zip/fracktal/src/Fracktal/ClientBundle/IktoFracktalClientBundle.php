<?php

namespace IKTO\Fracktal\ClientBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IktoFracktalClientBundle extends Bundle
{
}
