<?php

namespace IKTO\Fracktal\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IktoFracktalCoreBundle extends Bundle
{
}
